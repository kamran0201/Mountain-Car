Run as given in the problem statement

python mountain_car.py --task [T1/T2] --train [0/1]